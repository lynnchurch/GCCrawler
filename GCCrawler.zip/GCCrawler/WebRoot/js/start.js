function start() {
	$('#status').text("系统正在运行中...");
	var address=$('#input')[0].value;
	$.get('action.ControlAction', {
		command : 'start',address:address
	}, function(data) {
		getCrawlInfo();
	});	
	return false;
}

function getCrawlInfo(){
	$.get('action.ControlAction', {
		command : 'getCrawlInfo'
	}, function(data) {
		if(data=="抓取完毕！"){
			clearTimeout(t_id);
			$('#status').text("系统已停止运行。");
			alert("抓取完毕!");
		}
		if(data!=""&&data!="抓取完毕！"){
		datas+=data;
		$("#realSituation").html(datas);
		}
		$("#realSituation").animate({ scrollTop: $('#realSituation')[0].scrollHeight}, 500);
	});
	t_id=setTimeout("getCrawlInfo()",1000);
}
 



