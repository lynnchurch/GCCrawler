function view() {
	window.open('http://localhost:8080/GCCrawler/data/Projects.xml');
	return false;
}