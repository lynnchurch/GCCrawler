function backup() {
	$.get('action.ControlAction', {
		command : 'backup'
	},function(data){
		    data='http://localhost:8080/GCCrawler/'+data+'.zip';
			window.location.href=data;
	});
	
	return false;
}