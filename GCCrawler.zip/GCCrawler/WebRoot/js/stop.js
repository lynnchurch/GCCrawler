function stop() {
	clearTimeout(t_id);
	$.get('action.ControlAction', {
		command : 'stop'
	}, function(data) {
		if (data = "系统已停止运行。") {
			$('#status').text("系统已停止运行。");
			alert("系统已停止运行。");
			status = 'stop';
		}
	});
	return false;
}
