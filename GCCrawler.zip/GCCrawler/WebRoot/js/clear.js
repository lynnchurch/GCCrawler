function del() {
		$.get('action.ControlAction', {
			command : 'clear'
		}, function(data) {
			if (data == "数据已清空！") {
				$("#realSituation").html("");
				alert("数据已清空！");
			}
		});
	return false;
}