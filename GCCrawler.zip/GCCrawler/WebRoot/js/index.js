var status = "stop"; // 系统运行状态
var datas="";  // 从服务器接收的数据
var t_id; // 定时器ID号

$(document).ready(function() {
	input();
	$.getScript('js/start.js');
	$.getScript('js/stop.js');
	$.getScript('js/clear.js');
	$.getScript('js/view.js');
	$.getScript('js/backup.js');

	
	$('#a_start').click(function() {
		if (status == "stop") {
			status = "running";
			start();			
		}
	});

	$('#a_stop').click(function() {
		if (status == "running") {
			stop();
		}
	});
	
	$('#a_delete').click(function() {
		if (status == "stop") {
			del();
		}
		else{
			alert("系统正在运行中！请先终止系统运行！")
		}
	});
	
	$('#a_view').click(function() {
		view();
	});
	
	$('#a_backup').click(function() {
		if (status == "stop") {
			backup();
		}
		else{
			alert("系统正在运行中！请先终止系统运行！")
		}
	});

});

function input() {
	$('#input').focus(function() { //地址框获得鼠标焦点
				var address = $(this)[0].value; //得到当前文本框的值ֵ
				if (address == this.defaultValue) {
					$(this).val("");
				}
			});

	$('#input').blur(function() { //地址框失去鼠标焦点
				var address = $(this)[0].value;
				if (address == "") {
					$(this).val(this.defaultValue);
				}
			});
}