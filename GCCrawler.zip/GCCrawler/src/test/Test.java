﻿package test;

import java.io.IOException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.apache.http.client.ClientProtocolException;
import logic.CrawlerLogic;

public class Test {

	/**
	 * @param args
	 * @throws IOException
	 * @throws ClientProtocolException
	 */

	public static void main(String[] args) throws ClientProtocolException,
			IOException {

		 
//		String url = "https://code.google.com/p/foobnix/";
//		String url ="https://code.google.com/p/google-web-toolkit/";
//		String url = "https://code.google.com/p/mobicents/";
//		String url = "https://code.google.com/p/glossword/";
		// 设置初始URL
		 CrawlerLogic.setInitialUrl("https://code.google.com");
		// 并发线程数量
		 int threads=5; 
		 ExecutorService es=Executors.newFixedThreadPool(threads);
		 for(int i=0;i<threads;i++){
			 CrawlerLogic cl=new CrawlerLogic();
			 es.submit(cl);
		 }
		 es.shutdown();
		 
	}
}
