﻿package logic;

import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Date;

import org.apache.http.HttpEntity;
import org.apache.http.HttpStatus;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;

public class DownloadFileLogic {
	// 创建连接池管理器
	private static PoolingHttpClientConnectionManager phccm = new PoolingHttpClientConnectionManager();
	static {
		// 设置每个主机的最大并行链接数
		phccm.setDefaultMaxPerRoute(20);
		// 设置客户端总并行链接最大数
		phccm.setMaxTotal(100);
	}

	/**
	 * 根据URL生成需要保存的网页的文件名，去除URL 中的非文件名字符
	 */
	public String getFileNameByUrl(String url) {
		// 移除http://和https://
		if (-1 == url.indexOf("http://")) {
			url = url.substring(7);
		} else {
			url = url.substring(8);
		}

		url = url.replaceAll("[\\?/:*|<>\"]", "_") + ".html";
		return url;
	}

	/**
	 * 保存网页到本地文件，response为http响应对象，filePath 为要保存的文件的相对地址
	 */
	private void saveToLocal(CloseableHttpResponse response, String filePath) {
		HttpEntity he = response.getEntity();
		File file = new File(filePath);
		// 如果该文件已存在则直接返回不进行下载
		if (file.exists()) {
			return;
		}
		DataOutputStream out = null;
		try {
			out = new DataOutputStream(new FileOutputStream(file));
			he.writeTo(out);
			
			
		} catch (IOException e) {
			e.printStackTrace();
		}
		finally{
			try {
				response.close();
				out.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	/**
	 * 
	 * 下载URL 指向的网页
	 */
	public String downloadFile(String url) {
		long preTime=0; // 下载页面前当前系统时间
		long nexTime=0; // 下载页面完成后当前系统时间
		preTime=new Date().getTime();
		String filePath = null;
		// 生成 httpClinet对象
		CloseableHttpClient httpClient = HttpClients.custom()
				.setConnectionManager(phccm).build();

		// 生成httpGet对象
		HttpGet httpGet = new HttpGet(url);

		// 设置请求超时
		RequestConfig requestConfig = RequestConfig.custom()
				.setConnectionRequestTimeout(1000).setConnectTimeout(1000)
				.setSocketTimeout(2000).build();
		httpGet.setConfig(requestConfig);

		try {
			// 执行HTTP GET 请求
			CloseableHttpResponse response = httpClient.execute(httpGet);
			int statusCode = response.getStatusLine().getStatusCode();
			// System.out.println("StatusCode="+statusCode);
			// 判断访问的状态码
			if (statusCode != HttpStatus.SC_OK) {
				System.err
						.println("Method failed: " + response.getStatusLine());
				filePath = null;
			}
			// 根据网页url 生成保存时的文件名
//			filePath = "HtmlFiles\\" + getFileNameByUrl(url);  // 单机版保存路径
			
			String sysPath=System.getProperty("user.dir");
			filePath = sysPath.substring(0,sysPath.lastIndexOf("\\"))+"\\webapps\\GCCrawler\\HtmlFiles\\" + getFileNameByUrl(url); // Web版保存路径
			// 保存网页到本地文件
			saveToLocal(response, filePath);
		} catch (IOException e) {
			// 发生网络异常重连
			e.printStackTrace();
			System.out.println("url:" + url);
			return null;
		} finally {
			// 释放连接
			httpGet.releaseConnection();
		}
		nexTime=new Date().getTime();
//		System.out.println("DownloadTime:"+(nexTime-preTime)); // 下载一个页面所耗费的时间（单位为毫秒）
		return filePath;
	}
}
