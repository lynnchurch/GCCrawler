﻿package logic;

import java.io.File;
import java.io.IOException;
import java.util.Calendar;
import java.util.HashSet;
import java.util.LinkedList;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import entity.ProjectBean;
import form.ResultsForm;

public class ParseHtmlLogic {

	private Document doc = null; // 有关“/p/”生成的Document对象

	public ParseHtmlLogic(File file) {
		try {
			doc = Jsoup.parse(file, "UTF-8");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * 
	 * @author QZL 对html文件中的链接进行过滤，过滤出以“https://code.google.com/hosting/search”、
	 *         “/hosting/search”、“/p/”开头的链接
	 */
	public LinkedList<String> filtURL() {
		LinkedList<String> linkedList = new LinkedList<String>();
		Elements links = doc
				.select("a[href^=https://code.google.com/hosting/search],a[href^=/hosting/search],a[href^=/p/]");
		for (Element link : links) {
			// 提取出href属性中的链接，并将相对链接转换成绝对链接
			String linkHref = link.attr("href");
			if (-1 == linkHref.indexOf("https://")
					&& -1 == linkHref.indexOf("http://")) {
				linkHref = "https://code.google.com" + link.attr("href");
			}
			linkedList.add(linkHref);
		}
		return linkedList;
	}

	/**
	 * 将解析出的项目数据封装成ProjectBean对象返回
	 * 
	 * @return
	 */
	public  ProjectBean  getProjectBean() {
		ProjectBean projectBean = new ProjectBean(); // 创建用于向XML文件写入数据的工程数据实体对象
		ResultsForm rf = ResultsForm.creatResultsForm(); // 创建用于向浏览器实时显示解析情况的数据结构对象

		String url = getUrl();
		projectBean.setUrl(url);
		rf.putProjectData("url:"+url);

		int paticipators = getPaticipators();
		projectBean.setParticipators(paticipators);
		rf.putProjectData("paticipators:" + paticipators);

		int files = getFiles();
		projectBean.setFiles(files);
		rf.putProjectData("files:" + files);

		int bugs = getBugs();
		projectBean.setBugs(bugs);
		rf.putProjectData("bugs:" + bugs);

		int activeUsers = getActiveUsers();
		projectBean.setActiveUsers(activeUsers);
		rf.putProjectData("activeUsers:" + activeUsers);

		String technology = getTechnology();
		projectBean.setTechnology(technology);
		rf.putProjectData("technology:"+technology);

		int downloads = getDownloads();
		projectBean.setDownloads(downloads);
		rf.putProjectData("downloads:" + downloads);

		int committers = getCommitters();
		projectBean.setCommitters(committers);
		rf.putProjectData("committers:" + committers);

		int contributors = getContributors();
		projectBean.setContributors(contributors);
		rf.putProjectData("contributors:" + contributors);

		String codeLicense = getCodeLicense();
		projectBean.setCodeLicense(codeLicense);
		rf.putProjectData("codeLicense:"+codeLicense);

		int releases = getReleases();
		projectBean.setReleases(releases);
		rf.putProjectData("releases:" + releases);

		int uploads = getUploads();
		projectBean.setUploads(uploads);
		rf.putProjectData("uploads:" + uploads);

		return projectBean;
	}

	/**
	 * 解析出有关“/people/list”的链接，获取参与人数
	 * 
	 * @return
	 */
	public int getPaticipators() {
		int i_participators = 0;
		String dURL = null; // 下载至本地有关“/people/list”的html文件路径
		File file = null; // 有关“/people/list”的File对象
		Document doc = null; // 有关“/people/list”的Document对象

		// 筛选出href属性包含/people/list的链接
		Element link = this.doc.select("a[href*=/people/list]").first();
		if (link == null) {
			return -1;
		}
		// 提取出以上所筛选出的链接地址
		dURL = link.attr("href");

		// 对相对链接地址进行处理
		if (-1 == dURL.indexOf("https://") && -1 == dURL.indexOf("http://")) {
			dURL = "https://code.google.com" + dURL;
		}
		// 下载有关“/people/list”的html文件至本地
		String temp = null;
		do {
			temp = new DownloadFileLogic().downloadFile(dURL);
		} while (temp == null);
		file = new File(temp);
		try {
			// 用Jsoup加载已下载至本地的有关html文件
			doc = Jsoup.parse(file, "UTF-8");
		} catch (IOException e1) {
			e1.printStackTrace();
		}

		// 选择出class=pagination的div标签
		Element e = doc.select("div.pagination").first();
		if (e == null) {
			return -1;
		}

		// 获取以上div的文本内容
		String s_paticipators = e.text();

		// 对文本内容进行处理，提取出有关参与人数的数据
		if (s_paticipators.indexOf("Next") != -1) {
			s_paticipators = s_paticipators.substring(
					s_paticipators.indexOf("of") + 2,
					s_paticipators.indexOf("Next")).trim();
		} else {
			s_paticipators = s_paticipators.substring(
					s_paticipators.indexOf("of") + 2).trim();
		}

		i_participators = Integer.valueOf(s_paticipators);
		System.out.println("participators=" + i_participators);
		return i_participators;
	}

	/**
	 * 解析出有关“/downloads/list”的链接，获取文件数
	 * 
	 * @return
	 */
	public int getFiles() {
		int i_files = 0;
		String dURL = null; // 下载至本地有关“/downloads/list”的html文件路径
		File file = null; // 有关“/downloads/list”的File对象
		Document doc = null; // 有关“/downloads/list”的Document对象

		// 筛选出href属性包含/downloads/list的链接
		Element link = this.doc.select("a[href*=/downloads/list]").first();
		if (link == null) {
			return -1;
		}
		// 提取出以上所筛选出的链接地址
		dURL = link.attr("href");
		// 对提取出来的链接地址加上参数以访问有关“All downloads”的页面
		dURL = dURL
				+ "?can=1&q=&colspec=Filename+Summary+Uploaded+ReleaseDate+Size+DownloadCount";
		// 对相对链接地址进行处理
		if (-1 == dURL.indexOf("https://") && -1 == dURL.indexOf("http://")) {
			dURL = "https://code.google.com" + dURL;
		}
		// 下载有关“/downloads/list”的html文件至本地
		String temp = null;
		do {
			temp = new DownloadFileLogic().downloadFile(dURL);
		} while (temp == null);
		file = new File(temp);
		try {
			// 用Jsoup加载已下载至本地的有关html文件
			doc = Jsoup.parse(file, "UTF-8");
		} catch (IOException e1) {
			e1.printStackTrace();
		}

		// 选择出class=pagination的div标签
		Element e = doc.select("div.pagination").first();
		if (e == null) {
			return i_files;
		}
		// 获取以上div的文本内容
		String s_files = e.text();

		// 对文本内容进行处理，提取出有关文件数的数据
		if (s_files.indexOf("Next") != -1) {
			s_files = s_files.substring(s_files.indexOf("of") + 2,
					s_files.indexOf("Next")).trim();
		} else {
			s_files = s_files.substring(s_files.indexOf("of") + 2).trim();
		}

		i_files = Integer.valueOf(s_files);
		System.out.println("files=" + i_files);
		return i_files;
	}

	/**
	 * 解析出有关“/issues/list”的链接，获取Bug数
	 * 
	 * @return
	 */
	public int getBugs() {
		int i_bugs = 0;
		String dURL = null; // 下载至本地有关“/issues/list”的html文件路径
		File file = null; // 有关“/issues/list”的File对象
		Document doc = null; // 有关“/issues/list”的Document对象

		// 筛选出href属性包含/issues/list的链接
		Element link = this.doc.select("a[href*=/issues/list]").first();
		if (link == null) {
			return -1;
		}
		// 提取出以上所筛选出的链接地址
		dURL = link.attr("href");
		// 对提取出来的链接地址加上参数以访问有关“All issues”的页面
		dURL = dURL
				+ "?can=1&q=&colspec=ID+Type+Status+Priority+Milestone+Owner+Summary&cells=tiles";
		// 对相对链接地址进行处理
		if (-1 == dURL.indexOf("https://") && -1 == dURL.indexOf("http://")) {
			dURL = "https://code.google.com" + dURL;
		}
		// 下载有关“/issues/list”的html文件至本地
		String temp = null;
		do {
			temp = new DownloadFileLogic().downloadFile(dURL);
		} while (temp == null);
		file = new File(temp);
		try {
			// 用Jsoup加载已下载至本地的有关html文件
			doc = Jsoup.parse(file, "UTF-8");
		} catch (IOException e1) {
			e1.printStackTrace();
		}

		// 选择出class=pagination的div标签
		Element e = doc.select("div.pagination").first();
		if (e == null) {
			return i_bugs;
		}
		// 获取以上div的文本内容
		String s_bugs = e.text();

		// 对文本内容进行处理，提取出有关开发版本数的数据

		if (s_bugs.indexOf("Next") != -1) {
			s_bugs = s_bugs.substring(s_bugs.indexOf("of") + 2,
					s_bugs.indexOf("Next")).trim();
		} else {
			s_bugs = s_bugs.substring(s_bugs.indexOf("of") + 2).trim();
		}

		i_bugs = Integer.valueOf(s_bugs);
		System.out.println("bugs=" + i_bugs);
		return i_bugs;
	}

	/**
	 * 解析出有关“/w/list”的链接，获取活跃用户数
	 * 
	 * @return
	 */
	public int getActiveUsers() {
		int i_activeUsers = 0;
		String dURL = null; // 下载至本地有关“/w/list”的html文件路径
		File file = null; // 有关“/w/list”的File对象
		Document doc = null; // 有关“/w/list”的Document对象

		// 筛选出href属性包含/w/list的链接
		Element link = this.doc.select("a[href*=/w/list]").first();
		if (link == null) {
			return -1;
		}
		// 提取出以上所筛选出的链接地址
		dURL = link.attr("href");
		// 对相对链接地址进行处理
		if (-1 == dURL.indexOf("https://") && -1 == dURL.indexOf("http://")) {
			dURL = "https://code.google.com" + dURL;
		}
		// 下载有关“/w/list”的html文件至本地
		String temp = null;
		do {
			temp = new DownloadFileLogic().downloadFile(dURL);
		} while (temp == null);
		file = new File(temp);
		try {
			// 用Jsoup加载已下载至本地的有关html文件
			doc = Jsoup.parse(file, "UTF-8");
		} catch (IOException e1) {
			e1.printStackTrace();
		}

		// 将含用户名的那一列筛选出来
		Elements es = doc.select("td[class=vt col_3]>a");
		if (es == null) {
			return i_activeUsers;
		}
		HashSet<String> users = new HashSet<String>();
		for (Element e : es) {
			String user = e.text();
			// 防止用户名重名，方便统计活跃用户数量
			if (users.contains(user) != true) {
				users.add(user);
			}
		}

		i_activeUsers = users.size();
		System.out.println("activeUsers=" + i_activeUsers);
		return i_activeUsers;
	}

	/**
	 * 从有关“https://code.google.com/p/”链接中直接获取开发技术
	 * 
	 * @return
	 */
	public String getTechnology() {
		String technology = null;
		Element span = this.doc.select("span#project_labels").first();
		if (span == null) {
			return null;
		}
		technology = span.text();
		// 去除文本中的“Labels”字符串
		technology = technology.substring(6);
		System.out.println("technology=" + technology);
		return technology;
	}

	/**
	 * 解析出有关“/downloads/list”的链接，获取下载量
	 * 
	 * @return
	 */
	public int getDownloads() {
		int i_downloads = 0;
		String dURL = null; // 下载至本地有关“/downloads/list”的html文件路径
		String nURL = null; // 对dURL进行一个备份
		File file = null; // 有关“/downloads/list”的File对象
		Document doc = null; // 有关“/downloads/list”的Document对象

		// 筛选出href属性包含/downloads/list的链接
		Element link = this.doc.select("a[href*=/downloads/list]").first();
		if (link == null) {
			return -1;
		}
		// 提取出以上所筛选出的链接地址
		dURL = link.attr("href");
		// 对相对链接地址进行处理
		if (-1 == dURL.indexOf("https://") && -1 == dURL.indexOf("http://")) {
			dURL = "https://code.google.com" + dURL;
		}
		nURL = dURL;
		// 对提取出来的链接地址加上参数以访问有关“All downloads”的页面
		dURL = dURL
				+ "?can=1&q=&colspec=Filename+Summary+Uploaded+ReleaseDate+Size+DownloadCount";

		// 下载有关“/downloads/list”的html文件至本地
		String temp = null;
		do {
			temp = new DownloadFileLogic().downloadFile(dURL);
		} while (temp == null);
		file = new File(temp);
		try {
			// 用Jsoup加载已下载至本地的有关html文件
			doc = Jsoup.parse(file, "UTF-8");
		} catch (IOException e1) {
			e1.printStackTrace();
		}

		// 将含下载量的那一列筛选出来
		Elements es = doc.select("td[class=vt col_5]>a");
		if (es == null) {
			return i_downloads;
		}
		for (Element e : es) {
			// 对各文件的下载量求总和
			i_downloads += Integer.valueOf(e.text());
		}

		// 如果还有下一页，则继续解析获取下载量数据并与已获取的下载量数据进行求和
		while (doc.select("div.pagination").text().indexOf("Next") != -1) {
			Element en = doc.select("div[class=pagination]>a:contains(Next)")
					.first();
			if (en == null) {
				return i_downloads;
			}
			String sn = en.attr("href");
			sn = nURL.substring(0, nURL.indexOf("list")) + sn;

			// 下载有关“Next”的html文件至本地
			temp = null;
			do {
				temp = new DownloadFileLogic().downloadFile(sn);
			} while (temp == null);
			file = new File(temp);
			try {
				// 用Jsoup加载已下载至本地的有关html文件
				doc = Jsoup.parse(file, "UTF-8");
			} catch (IOException e1) {
				e1.printStackTrace();
			}
			es = doc.select("td[class=vt col_5]>a");
			if (es == null) {
				return i_downloads;
			}
			for (Element e : es) {
				i_downloads += Integer.valueOf(e.text());
			}
		}

		System.out.println("downloads=" + i_downloads);
		return i_downloads;
	}

	/**
	 * 解析出有关“/people/list”的链接，获取提交者数
	 * 
	 * @return
	 */
	public int getCommitters() {
		int i_committers = 0;
		String dURL = null; // 下载至本地有关“/people/list”的html文件路径
		String nURL = null; // 对dURL进行一个备份
		File file = null; // 有关“/people/list”的File对象
		Document doc = null; // 有关“/people/list”的Document对象

		// 筛选出href属性包含/people/list的链接
		Element link = this.doc.select("a[href*=/people/list]").first();
		if (link == null) {
			return -1;
		}
		// 提取出以上所筛选出的链接地址
		dURL = link.attr("href");
		// 对相对链接地址进行处理
		if (-1 == dURL.indexOf("https://") && -1 == dURL.indexOf("http://")) {
			dURL = "https://code.google.com" + dURL;
		}
		nURL = dURL;

		// 下载有关“/people/list”的html文件至本地
		String temp = null;
		do {
			temp = new DownloadFileLogic().downloadFile(dURL);
		} while (temp == null);
		file = new File(temp);
		try {
			// 用Jsoup加载已下载至本地的有关html文件
			doc = Jsoup.parse(file, "UTF-8");
		} catch (IOException e1) {
			e1.printStackTrace();
		}

		// 将含参与者角色那一列数据筛选出来
		Elements es = doc.select("td[class=vt col_1]>a");
		if (es == null) {
			return i_committers;
		}
		for (Element e : es) {
			// 筛选统计提交者数
			if (e.text().indexOf("Committer") != -1) {
				i_committers++;
			}
		}

		// 如果还有下一页，则继续解析获取筛选统计提交者数并与已获取的提交者数进行求和
		while (doc.select("div.pagination").text().indexOf("Next") != -1) {
			Element en = doc.select("div[class=pagination]>a:contains(Next)")
					.first();
			if (en == null) {
				return i_committers;
			}
			String sn = en.attr("href");
			sn = nURL.substring(0, nURL.indexOf("list")) + sn;
			// 下载有关“Next”的html文件至本地
			temp = null;
			do {
				temp = new DownloadFileLogic().downloadFile(sn);
			} while (temp == null);
			file = new File(temp);
			try {
				// 用Jsoup加载已下载至本地的有关html文件
				doc = Jsoup.parse(file, "UTF-8");
			} catch (IOException e1) {
				e1.printStackTrace();
			}
			es = doc.select("td[class=vt col_1]>a");
			if (es == null) {
				return i_committers;
			}
			for (Element e : es) {
				// 筛选统计提交者数
				if (e.text().indexOf("Committer") != -1) {
					i_committers++;
				}
			}
		}
		System.out.println("committers=" + i_committers);
		return i_committers;
	}

	/**
	 * 解析出有关“/people/list”的链接，获取捐助者数
	 * 
	 * @return
	 */
	public int getContributors() {
		int i_contributors = 0;
		String dURL = null; // 下载至本地有关“/people/list”的html文件路径
		String nURL = null; // 对dURL进行一个备份
		File file = null; // 有关“/people/list”的File对象
		Document doc = null; // 有关“/people/list”的Document对象

		// 筛选出href属性包含/people/list的链接
		Element link = this.doc.select("a[href*=/people/list]").first();
		if (link == null) {
			return i_contributors;
		}
		// 提取出以上所筛选出的链接地址
		dURL = link.attr("href");

		// 对相对链接地址进行处理
		if (-1 == dURL.indexOf("https://") && -1 == dURL.indexOf("http://")) {
			dURL = "https://code.google.com" + dURL;
		}
		nURL = dURL;

		// 下载有关“/people/list”的html文件至本地
		String temp = null;
		do {
			temp = new DownloadFileLogic().downloadFile(dURL);
		} while (temp == null);
		file = new File(temp);
		try {
			// 用Jsoup加载已下载至本地的有关html文件
			doc = Jsoup.parse(file, "UTF-8");
		} catch (IOException e1) {
			e1.printStackTrace();
		}

		// 将含参与者角色那一列数据筛选出来
		Elements es = doc.select("td[class=vt col_1]>a");
		if (es == null) {
			return i_contributors;
		}
		for (Element e : es) {
			// 筛选统计贡献者数
			if (e.text().indexOf("Contributor") != -1) {
				i_contributors++;
			}
		}

		// 如果还有下一页，则继续解析获取筛选统计贡献者数并与已获取的贡献者数进行求和
		while (doc.select("div.pagination").text().indexOf("Next") != -1) {
			Element en = doc.select("div[class=pagination]>a:contains(Next)")
					.first();
			if (en == null) {
				return i_contributors;
			}
			String sn = en.attr("href");
			sn = nURL.substring(0, nURL.indexOf("list")) + sn;
			// 下载有关“Next”的html文件至本地
			temp = null;
			do {
				temp = new DownloadFileLogic().downloadFile(sn);
			} while (temp == null);
			file = new File(temp);
			try {
				// 用Jsoup加载已下载至本地的有关html文件
				doc = Jsoup.parse(file, "UTF-8");
			} catch (IOException e1) {
				e1.printStackTrace();
			}
			es = doc.select("td[class=vt col_1]>a");
			if (es == null) {
				return i_contributors;
			}
			for (Element e : es) {
				// 筛选统计贡献者数
				if (e.text().indexOf("Contributor") != -1) {
					i_contributors++;
				}
			}
		}
		System.out.println("contributors=" + i_contributors);
		return i_contributors;
	}

	/**
	 * 从有关“https://code.google.com/p/”链接中直接获取许可证代码
	 * 
	 * @return
	 */
	public String getCodeLicense() {
		String codeLicense = null;
		Element link = this.doc.select("li.psmeta>a").get(1);
		if (link == null) {
			return null;
		}
		codeLicense = link.text();
		System.out.println("codeLicense=" + codeLicense);
		return codeLicense;
	}

	/**
	 * 解析出有关“/downloads/list”的链接，获取发布次数
	 * 
	 * @return
	 */
	public int getReleases() {
		int i_releases = 0;
		String dURL = null; // 下载至本地有关“/downloads/list”的html文件路径
		String nURL = null; // 对dURL进行一个备份
		File file = null; // 有关“/downloads/list”的File对象
		Document doc = null; // 有关“/downloads/list”的Document对象

		// 筛选出href属性包含/downloads/list的链接
		Element link = this.doc.select("a[href*=/downloads/list]").first();
		if (link == null) {
			return -1;
		}
		// 提取出以上所筛选出的链接地址
		dURL = link.attr("href");
		// 对相对链接地址进行处理
		if (-1 == dURL.indexOf("https://") && -1 == dURL.indexOf("http://")) {
			dURL = "https://code.google.com" + dURL;
		}
		nURL = dURL;
		// 对提取出来的链接地址加上参数以访问有关“All downloads”的页面
		dURL = dURL
				+ "?can=1&q=&colspec=Filename+Summary+Uploaded+ReleaseDate+Size+DownloadCount";

		// 下载有关“/downloads/list”的html文件至本地
		String temp = null;
		do {
			temp = new DownloadFileLogic().downloadFile(dURL);
		} while (temp == null);
		file = new File(temp);
		try {
			// 用Jsoup加载已下载至本地的有关html文件
			doc = Jsoup.parse(file, "UTF-8");
		} catch (IOException e1) {
			e1.printStackTrace();
		}

		// 将含发布日期的那一列筛选出来
		Elements es = doc.select("td[class=vt col_3]>a");
		if (es == null) {
			return i_releases;
		}

		// 获取系统当前日期
		Calendar c = Calendar.getInstance();
		int year = c.get(Calendar.YEAR);

		for (Element e : es) {
			String text = e.text();
			if (text.indexOf(" ") == -1) {
				continue;

			}
			if ((year - Integer.valueOf(text.substring(text.indexOf(" ") + 1))) <= 5) {
				i_releases++;
			}
		}

		// 如果还有下一页，则继续解析获取发布次数数据并与已获取的发布次数数据进行求和
		while (doc.select("div.pagination").text().indexOf("Next") != -1) {
			Element en = doc.select("div[class=pagination]>a:contains(Next)")
					.first();
			String sn = en.attr("href");
			sn = nURL.substring(0, nURL.indexOf("list")) + sn;
			// 下载有关“Next”的html文件至本地
			temp = null;
			do {
				temp = new DownloadFileLogic().downloadFile(sn);
			} while (temp == null);
			file = new File(temp);
			try {
				// 用Jsoup加载已下载至本地的有关html文件
				doc = Jsoup.parse(file, "UTF-8");
			} catch (IOException e1) {
				e1.printStackTrace();
			}
			es = doc.select("td[class=vt col_3]>a");
			for (Element e : es) {
				String text = e.text();
				if (text.indexOf(" ") == -1) {
					continue;
				}
				if ((year - Integer.valueOf(text
						.substring(text.indexOf(" ") + 1))) <= 5) {
					i_releases++;
				}
			}
		}

		System.out.println("releases=" + i_releases);
		return i_releases;
	}

	/**
	 * 解析出有关“/downloads/list”的链接，获取上传次数
	 * 
	 * @return
	 */
	public int getUploads() {
		int i_uploads = 0;
		String dURL = null; // 下载至本地有关“/downloads/list”的html文件路径
		String nURL = null; // 对dURL进行一个备份
		File file = null; // 有关“/downloads/list”的File对象
		Document doc = null; // 有关“/downloads/list”的Document对象

		// 筛选出href属性包含/downloads/list的链接
		Element link = this.doc.select("a[href*=/downloads/list]").first();
		if (link == null) {
			return -1;
		}
		// 提取出以上所筛选出的链接地址
		dURL = link.attr("href");
		// 对相对链接地址进行处理
		if (-1 == dURL.indexOf("https://") && -1 == dURL.indexOf("http://")) {
			dURL = "https://code.google.com" + dURL;
		}
		nURL = dURL;
		// 对提取出来的链接地址加上参数以访问有关“All downloads”的页面
		dURL = dURL
				+ "?can=1&q=&colspec=Filename+Summary+Uploaded+ReleaseDate+Size+DownloadCount";

		// 下载有关“/downloads/list”的html文件至本地
		String temp = null;
		do {
			temp = new DownloadFileLogic().downloadFile(dURL);
		} while (temp == null);
		file = new File(temp);
		try {
			// 用Jsoup加载已下载至本地的有关html文件
			doc = Jsoup.parse(file, "UTF-8");
		} catch (IOException e1) {
			e1.printStackTrace();
		}

		// 将含上传日期的那一列筛选出来
		Elements es = doc.select("td[class=vt col_2]>a");
		if (es == null) {
			return i_uploads;
		}

		// 获取系统当前日期
		Calendar c = Calendar.getInstance();
		int year = c.get(Calendar.YEAR);

		for (Element e : es) {
			String text = e.text();
			if (text.indexOf(" ") == -1) {
				continue;

			}
			if ((year - Integer.valueOf(text.substring(text.indexOf(" ") + 1))) <= 5) {
				i_uploads++;
			}
		}

		// 如果还有下一页，则继续解析获取上传次数数据并与已获取的上传次数数据进行求和
		while (doc.select("div.pagination").text().indexOf("Next") != -1) {
			Element en = doc.select("div[class=pagination]>a:contains(Next)")
					.first();
			if (en == null) {
				return i_uploads;
			}
			String sn = en.attr("href");
			sn = nURL.substring(0, nURL.indexOf("list")) + sn;
			// 下载有关“Next”的html文件至本地
			temp = null;
			do {
				temp = new DownloadFileLogic().downloadFile(sn);
			} while (temp == null);
			file = new File(temp);
			try {
				// 用Jsoup加载已下载至本地的有关html文件
				doc = Jsoup.parse(file, "UTF-8");
			} catch (IOException e1) {
				e1.printStackTrace();
			}
			es = doc.select("td[class=vt col_2]>a");
			for (Element e : es) {
				String text = e.text();
				if (text.indexOf(" ") == -1) {
					continue;
				}
				if ((year - Integer.valueOf(text
						.substring(text.indexOf(" ") + 1))) <= 5) {
					i_uploads++;
				}
			}
		}

		System.out.println("uploads=" + i_uploads);
		return i_uploads;
	}

	/**
	 * 返回该项目的链接
	 * 
	 * @return
	 */
	public String getUrl() {
		String url = null;
		// 筛选出href属性包含/people/list的链接
		Element link = this.doc.select("a[href*=/people/list]").first();
		if (link == null) {
			return null;
		}
		// 提取出以上所筛选出的链接地址
		url = link.attr("href");
		// 对相对链接地址进行处理
		if (-1 == url.indexOf("https://") && -1 == url.indexOf("http://")) {
			url = "https://code.google.com" + url;
		}
		url = url.substring(0, url.indexOf("/people/list"));
		System.out.println("\nurl=" + url);
		return url;
	}

}
