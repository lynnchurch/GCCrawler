﻿package logic;

import java.io.File;
import java.util.LinkedList;

import biz.LinkQueueBiz;
import dao.ProjectDao;
import dao.ProjectDaoImpl;
import dao.URLDaoImpl;

public class CrawlerLogic implements Runnable {
	private DownloadFileLogic df;
	private ParseHtmlLogic phl;
	private static LinkQueueBiz linkQueueBiz;
	private static int mark=1; // 线程是否运行的标志，“1”表示可运行，其他表示停止
	

	static {
		String sysPath = System.getProperty("user.dir");
		String filePath = sysPath.substring(0, sysPath.lastIndexOf("\\"))
				+ "\\webapps\\GCCrawler\\URLs.xml";
		File file=new File(filePath);
		linkQueueBiz=URLDaoImpl.createURLDaoImpl().readURLInfo(file);
	}

	public static void setInitialUrl(String url) {
		// 向LinkQueueBiz数据结构中加入初始URL
		linkQueueBiz.addUnvisitedUrl(url);
	}

	public void run() {
		String urltodo = null;
		String filePath = null;
		File file = null;
		df = new DownloadFileLogic();
		ProjectDao pd = new ProjectDaoImpl();
		LinkedList<String> urls = null;
		
		System.out.println("linkQueueBiz:"+linkQueueBiz.unVisitedUrlIsEmpty());
		
		// 如果未访问URL队列为空，则再等10秒
		if (linkQueueBiz.unVisitedUrlIsEmpty()) {
			try {
				Thread.sleep(10000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}

		// 如果线程可运行且待处理的URL队列不为空则继续抓取数据
		while (1==mark&&!linkQueueBiz.unVisitedUrlIsEmpty()) {
			synchronized (linkQueueBiz) {
				// 从未访问的URL队列中取一条URL
				urltodo = linkQueueBiz.deUnvisitedUrl();
				// 将待处理的的URL加入已访问URL集中
				linkQueueBiz.addVisitedUrl(urltodo);
			}
			// System.out.println("urltodo=" + urltodo);

			// 保证html文件下载到本地成功后才进行后续的解析
			do {
				filePath = df.downloadFile(urltodo);
			} while (filePath == null);
			file = new File(filePath);
			phl = new ParseHtmlLogic(file);
			// 对取出的URL进行分析处理
			if (urltodo.indexOf("/p/") != -1) {// 对包含工程数据的链接进行处理
				// 将解析获得的数据保存在本地的XML中
				pd.writeProjInfo(phl.getProjectBean());
			} else {
				// 过滤出符合要求的URL
				urls = phl.filtURL();
				// 把过滤出的URL进行再处理后加入到待访问的URL队列中
				synchronized (linkQueueBiz) {
					for (String s : urls) {
						linkQueueBiz.addUnvisitedUrl(s);
					}
				}
			}
			// linkQueueBiz.listen();
		}
		
		if(mark!=1){
			URLDaoImpl.createURLDaoImpl().writeURLInfo(linkQueueBiz);
		}
		return;
	}

	public static int getMark() {
		return mark;
	}

	public static void setMark(int mark) {
		CrawlerLogic.mark = mark;
	}
}
