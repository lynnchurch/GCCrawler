﻿package dao;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.io.OutputFormat;
import org.dom4j.io.SAXReader;
import org.dom4j.io.XMLWriter;

import entity.ProjectBean;

public class ProjectDaoImpl implements ProjectDao {
	/**
	 * 把一条工程数据写入XML文件
	 * 
	 * @param projectBean
	 *            工程数据对象
	 * @return 执行情况
	 */
	public synchronized boolean writeProjInfo(ProjectBean projectBean) {
		// String filePath="Projects.xml"; // 单机版保存路径
		String sysPath = System.getProperty("user.dir");
		String filePath = sysPath.substring(0, sysPath.lastIndexOf("\\"))
				+ "\\webapps\\GCCrawler\\data\\Projects.xml"; // Web版保存路径
		File file = new File(filePath);
		Document document = null;
		Element root = null;
		XMLWriter writer = null;

		if (!file.exists()) {
			document = DocumentHelper.createDocument();
			// 增加根标签
			root = document.addElement("projects");
		} else {
			try {
				// 读取已存在的XML文件
				document = new SAXReader().read(file);
				file.delete();
				root = document.getRootElement();
			} catch (DocumentException e) {
				e.printStackTrace();
				return false;
			}
		}

		// 添加子标签并给其添加属性
		root.addElement("project").addAttribute("participators",
				"" + projectBean.getParticipators()).addAttribute("files",
				"" + projectBean.getFiles()).addAttribute("bugs",
				"" + projectBean.getBugs()).addAttribute("activeUsers",
				"" + projectBean.getActiveUsers()).addAttribute("technology",
				projectBean.getTechnology()).addAttribute("downloads",
				"" + projectBean.getDownloads()).addAttribute("committers",
				"" + projectBean.getCommitters()).addAttribute("contributors",
				"" + projectBean.getContributors()).addAttribute("codeLicense",
				"" + projectBean.getCodeLicense()).addAttribute("releases",
				"" + projectBean.getReleases()).addAttribute("uploads",
				"" + projectBean.getUploads()).addAttribute("url",
				projectBean.getUrl());
		// 进行格式设置
		OutputFormat format = OutputFormat.createPrettyPrint(); // 缩减型格式
		// OutputFormat format = OutputFormat.createCompactFormat();//紧凑型格式
		// 指定XML编码
		format.setEncoding("UTF-8");
		// 设置子标签换行显示
		format.setLineSeparator("\n\r");
		// 保留文本前后的空格
		// format.setTrimText(false);

		try {
			// 将内容写入XML文件中
			writer = new XMLWriter(new FileWriter(file), format);
			writer.write(document);
			writer.close();
		} catch (IOException e) {
			e.printStackTrace();
			return false;
		}

		return true;
	}
}