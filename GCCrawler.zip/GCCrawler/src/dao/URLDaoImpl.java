﻿package dao;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Set;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.io.OutputFormat;
import org.dom4j.io.SAXReader;
import org.dom4j.io.XMLWriter;

import biz.LinkQueueBiz;

public class URLDaoImpl implements URLDao {

	private static URLDaoImpl uRLDaoImpl = null;

	private URLDaoImpl() {

	}

	/**
	 * 将URL信息写入XML文件中
	 */
	public boolean writeURLInfo(LinkQueueBiz linkQueueBiz) {
		System.out.println("writeURLInfo!!!!");
		// String filePath="URLs.xml"; // 单机版保存路径
		String sysPath = System.getProperty("user.dir");
		String filePath = sysPath.substring(0, sysPath.lastIndexOf("\\"))
				+ "\\webapps\\GCCrawler\\data\\URLs.xml"; // Web版保存路径
		File file = new File(filePath);
		if (file.exists()) {
			file.delete();
		}
		Document document = null;
		Element root = null;
		XMLWriter writer = null;
		document = DocumentHelper.createDocument();
		// 增加根标签
		root = document.addElement("URLs");

		// 添加待访问URL
		if (!linkQueueBiz.unVisitedUrlIsEmpty()) {
			LinkedList<String> linList = linkQueueBiz.getUnVisitedUrl()
					.getQueue();
			for (String s : linList) {
				root.addElement("unVisitedURL").addText(s);
			}
		}

		// 添加已访问URL
		if (linkQueueBiz.getVisitedUrlNum() != 0) {
			Set<String> set = linkQueueBiz.getVisitedUrl();
			for (String s : set) {
				root.addElement("VisitedURL").addText(s);
			}
		}

		// 进行格式设置
		OutputFormat format = OutputFormat.createPrettyPrint();
		// 指定XML编码
		format.setEncoding("GBK");
		// 设置子标签换行显示
		format.setLineSeparator("\n\r");
		// 保留文本前后的空格
		format.setTrimText(false);

		try {
			// 将内容写入XML文件中
			writer = new XMLWriter(new FileWriter(file), format);
			writer.write(document);
			writer.close();
		} catch (IOException e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}

	/**
	 * 从XML文件中读取URL信息
	 */
	public LinkQueueBiz readURLInfo(File file) {
		LinkQueueBiz linkQueueBiz = LinkQueueBiz.creatLinkQueueBizObj();
		Document doc = null;
		Iterator<?> iter = null;
		SAXReader reader = new SAXReader();
		if (file.exists()) {
			try {
				doc = reader.read(file);
			} catch (DocumentException e) {
				e.printStackTrace();
			}
			// 获取根节点
			Element URLs = doc.getRootElement();
			// 获取根节点下的子节点unVisitedURL
			iter = URLs.elementIterator("unVisitedURL");
			while (iter.hasNext()) {
				Element unVisitedURL = (Element) iter.next();
				linkQueueBiz.addUnvisitedUrl(unVisitedURL.getText());
			}
			// 获取根节点下的子节点visitedURL
			iter = URLs.elementIterator("visitedURL");
			while (iter.hasNext()) {
				Element visitedURL = (Element) iter.next();
				linkQueueBiz.addVisitedUrl(visitedURL.getText());
			}
		}
		return linkQueueBiz;
	}

	static public URLDaoImpl createURLDaoImpl() {
		if (uRLDaoImpl == null) {
			return new URLDaoImpl();
		}
		return uRLDaoImpl;
	}

}
