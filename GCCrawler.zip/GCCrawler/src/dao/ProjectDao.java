﻿package dao;

import entity.ProjectBean;

public interface ProjectDao {
	/**
	 * 
	 * @param projectBean
	 *            工程数据对象
	 * @return 执行情况
	 */
	boolean writeProjInfo(ProjectBean projectBean);
}
