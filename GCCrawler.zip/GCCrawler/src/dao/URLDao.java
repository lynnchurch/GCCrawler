﻿package dao;

import java.io.File;

import biz.LinkQueueBiz;

public interface URLDao {
	/**
	 * 
	 * @param linkQueueBiz
	 *            URL数据结构
	 * @return 执行情况
	 */
	boolean writeURLInfo(LinkQueueBiz linkQueueBiz);
	LinkQueueBiz readURLInfo(File filePath);
}
