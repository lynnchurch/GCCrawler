﻿package action;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import biz.LinkQueueBiz;

import logic.CrawlerLogic;

import form.ResultsForm;

public class ControlAction extends HttpServlet {
	ExecutorService es; // 声明线程池

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {
		ResultsForm rf = ResultsForm.creatResultsForm();
		String command = request.getParameter("command");
		String address = request.getParameter("address");
		System.out.println("command: " + command);
		// System.out.println("address: " + address);

		// 设置响应内容的类型
		response.setContentType("text/html;charset=UTF-8");
		// 获取页面输出流
		PrintWriter out = response.getWriter();
		if (command.equals("start")) {
			// 并发线程数量
			int threads = 10;
			// 创建线程池
			es = Executors.newFixedThreadPool(threads);
			// 设置初始URL
			if (address.startsWith("https://code.google.com")
					|| address.startsWith("http://code.google.com")) {
				CrawlerLogic.setInitialUrl(address);
			} else {
				CrawlerLogic.setInitialUrl("https://code.google.com");
			}

			for (int i = 0; i < threads; i++) {
				CrawlerLogic cl = new CrawlerLogic();
				es.submit(cl); // 把任务提交到线程池中运行
			}
			es.shutdown();
		}

		if (command.equals("stop")) {
			CrawlerLogic.setMark(0);
			es.shutdown();
			System.out.println("shutdown!");
			// 等待剩余的任务执行完
			while (!es.isTerminated()) {
			}
			out.write("系统已停止运行。");
			CrawlerLogic.setMark(1);
			return;
		}

		if (command.equals("clear")) {
			// 获取系统运行的路径
			String sysPath = System.getProperty("user.dir");
			// Projects.xml文件存放路径
			String p_filePath = sysPath.substring(0, sysPath.lastIndexOf("\\"))
					+ "\\webapps\\GCCrawler\\data\\Projects.xml";
			new File(p_filePath).delete();
			// URLs.xml文件存放路径
			String u_filePath = sysPath.substring(0, sysPath.lastIndexOf("\\"))
					+ "\\webapps\\GCCrawler\\data\\URLs.xml";
			new File(u_filePath).delete();

			String path = sysPath.substring(0, sysPath.lastIndexOf("\\"))
					+ "\\webapps\\GCCrawler\\HtmlFiles";
			deleteFiles(path);
			out.write("数据已清空！");
			return;
		}

		if (command.equals("backup")) {
			// 设置日期格式
			SimpleDateFormat df = new SimpleDateFormat("yyyy_MM_dd_HH_mm_ss");
			// 获取系统当前时间
			String curSysTime = df.format(new Date());
			// 获取系统运行的路径
			String sysPath = System.getProperty("user.dir");
			// Projects.xml文件存放路径
			String p_filePath = sysPath.substring(0, sysPath.lastIndexOf("\\"))
					+ "\\webapps\\GCCrawler\\data";
			// 压缩后的Projects.zip文件存放路径
			String z_filePath = sysPath.substring(0, sysPath.lastIndexOf("\\"))
					+ "\\webapps\\GCCrawler\\" + curSysTime + ".zip";
			ZipFiles(z_filePath, p_filePath);
			out.write(curSysTime);
			return;
		}

		// 获取抓取数据用于浏览器显示
		String projectData = rf.getProjectData();
		// 直接生产响应
		out.write(projectData);
		// 判断任务是否执行完毕
		if (es != null) {
			System.out.println("isTerminated:" + es.isTerminated());
			if (es.isTerminated()) {
				out.write("抓取完毕！");
			}
		}
	}

	// 清空指定目录下的文件
	public void deleteFiles(String path) {
		File file = new File(path);
		if (file.isFile() || file.list().length == 0) {
			file.delete();
		} else {
			File[] files = file.listFiles();
			for (File f : files) {
				deleteFiles("" + f);// 递归删除每一个文件
				f.delete();// 删除该文件夹
			}
		}
		// file.delete();
	}

	// 压缩文件
	public void ZipFiles(String zipPath, String srcPath) {
		ZipOutputStream out = null;
		File zipFile = null;
		try {
			zipFile = new File(zipPath);
			out = new ZipOutputStream(new FileOutputStream(zipFile));
			ZipFiles(out, srcPath);
			out.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void ZipFiles(ZipOutputStream out, String path) {
		String srcDirName = path.substring(path.lastIndexOf("\\") + 1);
		File[] srcFiles = new File(path).listFiles();
		if (!path.endsWith("/")) {
			path += "/";
		}
		byte[] buf = new byte[1024];
		try {
			for (int i = 0; i < srcFiles.length; i++) {
				if (srcFiles[i].isDirectory()) {
					String srcPath = srcFiles[i].getName();
					if (!srcPath.endsWith("/")) {
						srcPath += "/";
					}
					String zipPath = (path + srcPath)
							.substring((path + srcPath).indexOf(srcDirName));
					out.putNextEntry(new ZipEntry(zipPath));
					ZipFiles(out, path + srcPath);
				} else {
					FileInputStream in = new FileInputStream(srcFiles[i]);
					String zipPath = (path + srcFiles[i].getName())
							.substring((path + srcFiles[i].getName())
									.indexOf(srcDirName));
					out.putNextEntry(new ZipEntry(zipPath));
					int len;
					while ((len = in.read(buf)) > 0) {
						out.write(buf, 0, len);
					}
					out.closeEntry();
					in.close();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void doGet(HttpServletRequest request,HttpServletResponse response) throws IOException, ServletException{
		doPost(request, response);
	}
}
