﻿package entity;

public class ProjectBean {
	private int participators; // 参与人数
	private int files; // 文件数
	private int bugs; // Bug数
	private int activeUsers; // 活跃用户数
	private String technology; // 涉及技术
	private int downloads; // 下载量
	private int committers; // 提交者数
	private int contributors; // 捐助者数
	private String codeLicense; // 许可证代码
	private int releases; // 发布次数（最近5年内文件发布次数）
	private int uploads; // 上传次数（最近5年内文件上传次数）
	private String url; // 工程数据获取链接

	public int getParticipators() {
		return participators;
	}

	public void setParticipators(int participators) {
		this.participators = participators;
	}

	public int getFiles() {
		return files;
	}

	public void setFiles(int files) {
		this.files = files;
	}

	public int getBugs() {
		return bugs;
	}

	public void setBugs(int bugs) {
		this.bugs = bugs;
	}

	public int getActiveUsers() {
		return activeUsers;
	}

	public void setActiveUsers(int activeUsers) {
		this.activeUsers = activeUsers;
	}

	public String getTechnology() {
		return technology;
	}

	public void setTechnology(String technology) {
		this.technology = technology;
	}

	public int getDownloads() {
		return downloads;
	}

	public void setDownloads(int downloads) {
		this.downloads = downloads;
	}

	public int getCommitters() {
		return committers;
	}

	public void setCommitters(int committers) {
		this.committers = committers;
	}

	public int getContributors() {
		return contributors;
	}

	public void setContributors(int contributors) {
		this.contributors = contributors;
	}

	public String getCodeLicense() {
		return codeLicense;
	}

	public void setCodeLicense(String codeLicense) {
		this.codeLicense = codeLicense;
	}

	public int getReleases() {
		return releases;
	}

	public void setReleases(int releases) {
		this.releases = releases;
	}

	public int getUploads() {
		return uploads;
	}

	public void setUploads(int uploads) {
		this.uploads = uploads;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

}
