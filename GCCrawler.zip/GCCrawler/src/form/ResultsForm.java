﻿package form;

import java.util.ArrayList;

public class ResultsForm{
	private int index=0; // 下一次从解析结果数据列表中获取数据的索引
	private ArrayList<String> projectDataList=new ArrayList<String>(); // 存放解析结果数据的列表，用于浏览器实时显示
    private static ResultsForm resultsForm=null; // 用于返回ResultsForm对象
    private ResultsForm(){
    	
    }
    
    // 向此列表插入一条工程数据
	public void putProjectData(String data){
		projectDataList.add(data+"<br>");
	}
	
	// 返回列表工程数据的条数
	public int size(){
		return projectDataList.size();
	}
	
	// 从解析结果数据列表中获取数据
	public String getProjectData(){
		String projectData="";
		while(index<size()){
			projectData+=projectDataList.get(index);
			index++;
		}
		return projectData;
	}
	
	// 返回一个ResultsForm对象
	static public ResultsForm creatResultsForm(){
		if(resultsForm==null){
			resultsForm=new ResultsForm();
		}
		return resultsForm;
	}
}