﻿package biz;

import java.util.LinkedList;
/**
 * 
 * 队列，保存将要访问的URL
 */
public class QueueBiz {
	// 使用链表实现队列
	private LinkedList<String> queue = new LinkedList<String>();

	// 入队列
	public void addLast(Object t) {
		queue.addLast((String) t);
	}

	// 获取queue属性值
	public LinkedList<String> getQueue(){
		return queue;
	}
	
	// 出队列
	public String removeFirst() {
		return queue.removeFirst();
	}

	// 判断队列是否为空
	public boolean isEmpty() {
		return queue.isEmpty();
	}

	// 判断队列是否包含元素objt
	public boolean contains(Object objt) {
		return queue.contains(objt);
	}
}
