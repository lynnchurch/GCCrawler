﻿package biz;

import java.util.HashSet;
import java.util.Set;


/**
 *队列，保存将要访问的URL，和已经访问过的URL
 */
public class LinkQueueBiz {
	private static LinkQueueBiz linkQueueBiz=null;
	// 已访问的url 集合
	private static Set<String> visitedUrl = new HashSet<String>();
	
	// 待访问的url 队列
	private static QueueBiz unVisitedUrl = new QueueBiz();
	
	private LinkQueueBiz(){
		
	}
	
	// 工厂方法
	public static LinkQueueBiz creatLinkQueueBizObj(){
		if(linkQueueBiz==null){
			linkQueueBiz=new LinkQueueBiz();
		}
		return linkQueueBiz;
	}
	// 获得已访问的URL集合	
	public  Set<String> getVisitedUrl(){
		return visitedUrl;
	}

	// 获得待访问的URL 队列
	public  QueueBiz getUnVisitedUrl() {
		return unVisitedUrl;
	}

	// 添加到访问过的URL 队列中
	public void addVisitedUrl(String url) {
		visitedUrl.add(url);
	}


	// 未访问的URL 出队列
	public  String deUnvisitedUrl() {
		return unVisitedUrl.removeFirst();
	}
	

	// 向未访问过的URL队列中增加URL，保证每个URL只被访问一次
	public  void addUnvisitedUrl(String url) {
		if (url != null && !url.trim().equals("") && !visitedUrl.contains(url)
				&& !unVisitedUrl.contains(url))
			unVisitedUrl.addLast(url);
	}

	// 获得已经访问的URL 数目
	public  int getVisitedUrlNum() {
		return visitedUrl.size();
	}

	// 判断未访问的URL 队列中是否为空
	public  boolean unVisitedUrlIsEmpty() {
		return unVisitedUrl.isEmpty();
	}
	
	// 监视数据情况
	public void listen(){
		System.out.println("visitedUrl:");
		for(String s:visitedUrl){
			System.out.println(s+" ");
		}
		
		System.out.println("unVisitedUrl:");
		for(String s:unVisitedUrl.getQueue()){
			System.out.println(s+" ");
		}
//		try {
//			Thread.sleep(10000);
//		} catch (InterruptedException e) {
//			e.printStackTrace();
//		}
	}
}
